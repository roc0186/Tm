import os,sys
case=int(sys.argv[1])
# folder=sys.argv[2]
folder = os.listdir('/job/data')[0]

pdbpath = os.path.join('/job/data',folder)
pdblist = sorted(os.listdir(pdbpath))
pdb = os.path.join(pdbpath,pdblist[case])
pdbbasename = os.path.basename(pdb)
outfolder = '/job/save/'+pdbbasename.split('.')[0]
cmd = ' '.join(['mkdir',outfolder,'&& cp traj*',outfolder,'&& cp prod*nc',outfolder,'&& cp wbox*',outfolder])

os.system(cmd)
