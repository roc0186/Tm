#!/usr/bin/env python

import mdtraj as md
import glob
import os
print(os.getcwd())
print(os.listdir('./'))

trajs = sorted(glob.glob('prod*.nc'))
#print(prod_trajs)

nc_list = list()

for traj in trajs:
    t = md.load(traj, top='wbox.pdb',stride=10)
    t.image_molecules(inplace=True)
    t = t.atom_slice(t.top.select("not resname HOH 'Cl-' 'Na+'"))   
    t.save('mol%s.nc'%traj[4:-3])
    nc_list.append(t)

mtraj = md.join(nc_list)
prot = mtraj.top.select('protein')
mtraj.superpose(mtraj[0], atom_indices=prot)
mtraj[0].save('traj_0.pdb')
mtraj.save('traj.dcd')


