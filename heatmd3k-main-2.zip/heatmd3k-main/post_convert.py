#!/usr/bin/env python

import mdtraj as md
import glob
import os
print(os.getcwd())
print(os.listdir('./'))
folder1 = os.listdir('/job/data')[0]
path1 = os.path.join('/job/data',folder1)
folder2 =os.listdir(path1)[0]
path2 = os.path.join(path1,folder2)
print(path2)
trajs = sorted(glob.glob(path2+'/prod*.nc'))
print(trajs)

nc_list = list()

for traj in trajs:
    t = md.load(traj, top=path2+'/wbox.pdb',stride=10)
    t.image_molecules(inplace=True)
    t = t.atom_slice(t.top.select("not resname HOH 'Cl-' 'Na+'"))   
    # t.save('mol%s.nc'%traj[4:-3])
    nc_list.append(t)
print(nc_list)
mtraj = md.join(nc_list)
prot = mtraj.top.select('protein')
mtraj.superpose(mtraj[0], atom_indices=prot)
mtraj[0].save('traj_0.pdb')
mtraj.save('traj.dcd')
os.system('cp traj* /job/save/')
