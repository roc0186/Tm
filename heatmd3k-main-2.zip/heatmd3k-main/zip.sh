tar -cvzf /job/save/a.tar.gz /job/data
