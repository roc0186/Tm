#!/bin/bash
# chmod 777 schedule
# ./schedule preprocess $1 VHH_models
python preprocess.py $1

tleap -s -f ./leap.in
pmemd.cuda -O -i min_1.in -o min_1.out -p wbox.prmtop -c wbox.inpcrd -r min_1.rst -ref wbox.inpcrd
pmemd.cuda -O -i min_2.in -o min_2.out -p wbox.prmtop -c min_1.rst -r min_2.rst
pmemd.cuda -O -i heat.in -o heat.out -p wbox.prmtop -c min_2.rst -x heat.nc -r heat.rst -ref min_2.rst
pmemd.cuda -O -i equil.in -o equil.out -p wbox.prmtop -c heat.rst -x equil.nc -r equil.rst
ln -s equil.rst prod000.rst

istart=1
iend=100

I=$istart
while [ $I -le $iend ]
do
  suffix=`printf %03d $I`
  suffix2=`printf %03d $((I-1))`
  T=`expr 295 + $((I*3))`
  cat prod.in |sed "s/298/$T/" > prod_$suffix.in
  pmemd.cuda -O -i prod_$suffix.in -o prod$suffix.out -p wbox.prmtop -c prod$suffix2.rst -x prod$suffix.nc -r prod$suffix.rst
  I=$((I+1))
done
# do
#   suffix=`printf %03d $I`
#   suffix2=`printf %03d $((I-1))`
#   pmemd.cuda -O -i prod.in -o prod$suffix.out -p wbox.prmtop -c prod$suffix2.rst -x prod$suffix.nc -r prod$suffix.rst
#   I=$((I+1))
# done
python convert.py

python postprocess.py $1
# tar -cvzf /job/save/job_{JOB_ID}_result.tar.gz *
# cp *dcd /job/save/
# cp *pdb /job/save/
#rm prod*.nc
# ./schedule postprocess
