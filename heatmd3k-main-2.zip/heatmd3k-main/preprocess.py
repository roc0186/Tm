import os,sys
case=int(sys.argv[1])
# folder=sys.argv[2]
folder = os.listdir('/job/data')[0]

pdbpath = os.path.join('/job/data',folder)
pdblist = sorted(os.listdir(pdbpath))
pdb = os.path.join(pdbpath,pdblist[case])
pdbbasename = os.path.basename(pdb)
cmd = ' '.join(['cp',pdb,pdbbasename,'&& ln -s',pdbbasename,'input.pdb'])

os.system(cmd)


